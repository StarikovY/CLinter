CLinter V1.0 - Windows AMD64

Extract the entire ZIP before running CLinter.
Open Command Prompt in the extracted directory.
Interactive mode: CLinter.exe
Run a sample: CLinter.exe samples\DuckHunt720p.bas
See docs for the English and Russian BASIC manuals.
Source: https://github.com/StarikovY/CLinter
License: LICENSE.txt
See README.md for project information.
Samples include Nebula.bas, Spiral.bas, DuckHuntText.bas,
DuckHuntD1.bas, DuckHunt720p.bas, StairwayCloudsDemo.bas, Eliza.bas and RegTest.bas.
