CLinter V1.0 - macOS ARM64

Extract the entire ZIP before running CLinter.
Open Terminal in the extracted directory.
Interactive mode: ./CLinter
Run a sample: ./CLinter samples/DuckHunt720p.bas
See docs for English and Russian BASIC manuals.
Source: https://github.com/StarikovY/CLinter
License: LICENSE.txt; SDL2 license: lib/SDL2_LICENSE.txt
See README.md for project information.
Samples include Nebula.bas, Spiral.bas, DuckHuntText.bas,
DuckHuntD1.bas, DuckHunt720p.bas, StairwayCloudsDemo.bas and RegTest.bas.
This package is ad-hoc signed, not Developer ID signed or notarized.
macOS Gatekeeper may require approval before running downloaded software.
